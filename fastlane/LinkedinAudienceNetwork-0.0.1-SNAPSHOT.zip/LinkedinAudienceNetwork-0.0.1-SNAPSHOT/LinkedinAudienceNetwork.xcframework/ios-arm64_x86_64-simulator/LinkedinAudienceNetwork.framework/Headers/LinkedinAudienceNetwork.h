#import <Foundation/Foundation.h>

//! Project version number for LinkedinAudienceNetwork.
FOUNDATION_EXPORT double LinkedinAudienceNetworkVersionNumber;

//! Project version string for LinkedinAudienceNetwork.
FOUNDATION_EXPORT const unsigned char LinkedinAudienceNetworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LinkedinAudienceNetwork/PublicHeader.h>


